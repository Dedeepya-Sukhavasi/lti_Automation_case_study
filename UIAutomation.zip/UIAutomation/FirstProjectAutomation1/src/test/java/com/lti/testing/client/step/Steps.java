package com.lti.testing.client.step;

import org.openqa.selenium.WebDriver;

import com.lti.testing.client.pageobject.content.Shopping;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Steps {

	public  WebDriver driver;
	Shopping sh=new Shopping(driver);
	
	
	@Given("User has launched the url")
	public void user_has_launched_the_url() {
		
		sh.lounch1();
     }

@When("user enter  Name as \"([^\\\"]*)\" and size \"([^\\\"]*)\" add to cart$")
	public void user_hits_on_search_button(String name,String size) {
	
	    sh.search1(name,size);
	}

@When("proceed to do checkout")
public void proceed_to_checkout(){
	sh.cart();
}

@Then ("Search Results are displayed")
public void search_results_are_displayed() {
Boolean Value=sh.validation();
if(!Value) {

	System.out.println("The sum and total not matching");

	}
	else
	{
		System.out.println("The sum and total is matching with all products unit price");
}
}

}

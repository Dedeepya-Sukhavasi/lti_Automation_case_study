package com.lti.testing.client.pageobject.content;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Shopping {
	
private WebDriver driver;
	
	public Shopping(WebDriver driver) {
		this.driver = driver;
	}


	public void lounch1() {

		System.setProperty("webdriver.chrome.driver", "C:\\selenium\\chromedriver.exe");
		driver= new ChromeDriver();
		driver.get("http://automationpractice.com/index.php");
		driver.manage().window().maximize();
		
	}
	
	public void search(String name,String size) {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(120));
		Actions action = new Actions(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver; 

		//Select size ;
		

			//WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(120));
	       WebElement searchtxtbox= wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='search_query_top']")));
			searchtxtbox.sendKeys(name);

			WebElement searchbtn= driver.findElement(By.xpath("//button[@name='submit_search']"));
			searchbtn.click();
		


			
			WebElement firstItem=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class=\"available-now\"]")));

			// Javascript executor
			((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", firstItem);

			//Creating object of an Actions class


			//Performing the mouse hover action on the target element firstItem.
			action.moveToElement(firstItem).build().perform();


			//Clicking on more button
			WebElement Morebtn= wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='More']")));
			Morebtn.click();
		
			Select size1 = new Select(driver.findElement(By.xpath("//*[@id='group_1']")));
			size1.selectByVisibleText(size);

			//In child window add to cart for the selected item.

			WebElement AddtoCartbtn=  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='Add to cart']")));
			AddtoCartbtn.click();

			WebElement ContinueShoppingbtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@title='Continue shopping']")));
			ContinueShoppingbtn.click();
			
			
	}
	public String ShippingCost()
	{
		String Shipping1=driver.findElement(By.xpath("//*[@id='total_shipping']")).getText();
		Shipping1=Shipping1.substring(1);
		Float Shipping11=Float.parseFloat(Shipping1);
		return Shipping1;

	}
	public Float unitPriceAndTotal1(int numOfProduct)
	{
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");
		String UnitPrice=" ";
		Float UnitPrice11=0.0F;
		for(int i=1;i<=numOfProduct;i++) {
			UnitPrice=driver.findElement(By.xpath("//table[@id='cart_summary']/tbody/tr["+i+"]/td[4]")).getText();
			UnitPrice=UnitPrice.substring(1);
			UnitPrice11 =UnitPrice11+Float.parseFloat(UnitPrice);
		}
		return UnitPrice11;



	}
	public Double TotalPrice()
	{
		
		String Totalprice=driver.findElement(By.xpath("//span[@id='total_price']")).getText();

		Totalprice=Totalprice.substring(1);

		Float Totalprice1=Float.parseFloat(Totalprice);
		Double Totalpricey = Totalprice1.doubleValue();  
		Totalpricey = Math.round(Totalpricey*100.0)/100.0;

		

	return Totalpricey;
	}
	
	public void search1(String Name ,String size) {
	WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(120));
	Actions action = new Actions(driver);
	JavascriptExecutor js = (JavascriptExecutor) driver; 

	//Select size ;
	

		//WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(120));
       WebElement searchtxtbox= wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id='search_query_top']")));
       searchtxtbox.clear();
     
       searchtxtbox.sendKeys(Name);

		WebElement searchbtn= driver.findElement(By.xpath("//button[@name='submit_search']"));
		searchbtn.click();
	


		
		WebElement firstItem=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//span[@class=\"available-now\"]")));

		// Javascript executor
		((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView(true);", firstItem);

		//Creating object of an Actions class


		//Performing the mouse hover action on the target element firstItem.
		action.moveToElement(firstItem).build().perform();


		//Clicking on more button
		WebElement Morebtn= wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='More']")));
		Morebtn.click();
	
		Select size1 = new Select(driver.findElement(By.xpath("//*[@id='group_1']")));
		size1.selectByVisibleText(size);

		//In child window add to cart for the selected item.

		WebElement AddtoCartbtn=  wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[text()='Add to cart']")));
		AddtoCartbtn.click();

		WebElement ContinueShoppingbtn = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@title='Continue shopping']")));
		ContinueShoppingbtn.click();
	}
	
	public void cart() {
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(120));
		WebElement Cart=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@class='shopping_cart']/a")));
		Actions action = new Actions(driver);
		JavascriptExecutor js = (JavascriptExecutor) driver; 
		action.moveToElement(Cart).build().perform();
//***********
		WebElement CheckOut=wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[contains(text(),'Check out')]")));

		CheckOut.click();
		
	    
		

	}
	
	public Boolean validation() {
		Float Unit=unitPriceAndTotal1(2);
		Double Unity = Unit.doubleValue();  
		Unity = Math.round(Unity*100.0)/100.0;
		String ship= ShippingCost();
		Float ship1=Float.parseFloat(ship);
		Double shipy = ship1.doubleValue();  
		shipy = Math.round(shipy*100.0)/100.0;
		Double UnitPrice= Unity + shipy;
		System.out.println("The total of indvidual products without shiping are: "+Unity);
		System.out.println("The shiping cost is: "+shipy);
		System.out.println("The total of indvidual products including shiping is: "+UnitPrice);
		Double Totalprice = TotalPrice();
		System.out.println("The total price of checked out items is: "+Totalprice);
		Boolean flag;
		if(Double.compare(UnitPrice, Totalprice) == 0) {

			flag = true;

			}
			else
			{
				flag = false;
			}
		
		 driver.quit();
			
	    return flag;
		
	}
	
}

package com.lti.testing.client.step;

import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.testng.ITestContext;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.restassured.http.ContentType;
//import io.restassured.RestAssured;
import io.restassured.response.Response;
import static io.restassured.RestAssured.*;
import static io.restassured.matcher.RestAssuredMatchers.*;
import static org.hamcrest.Matchers.*;

public class API {


	
	@Test(dataProvider = "status",priority=1)
    public void testMethod(String param) {
	
		given()
		.get("https://petstore.swagger.io/v2/pet/findByStatus?status="+param)
		.then()
		.statusCode(200)
		.body("status", hasItems(param) )	
		.log().all()
		;
    }

    @DataProvider
    public Object[][] status() {
        String[] status={"available", "pending","sold"};
       
        Object[][] returnValues = new Object[status.length][1];
        int index = 0;
        for (Object[] each : returnValues) {
        	System.out.println(each);
            each[0] = status[index++].trim();
        }
        return returnValues;



    }


    @Test(priority=2)
	public void test_post(){	
		// post	

		JSONObject request=new JSONObject();
		request.put("id","1");
		request.put("petId","1");

		request.put("quantity","1");
		request.put("shipDate","2022-06-29T05:13:47.704Z");
		request.put("status1","placed");
		request.put("complete",true);


		System.out.println(request.toJSONString());

		given()
		.header("Content-Type","application/json")
		.contentType(ContentType.JSON)
		.accept(ContentType.JSON)
		.body(request.toJSONString())
		.when()
		.post("https://petstore.swagger.io/v2/store/order")
		.then().
		statusCode(200);
	}






}

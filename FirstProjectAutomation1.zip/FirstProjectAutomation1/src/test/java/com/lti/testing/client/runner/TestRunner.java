package com.lti.testing.client.runner;
//import org.junit.runner.RunWit

import org.junit.runner.RunWith;
import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
@RunWith(Cucumber.class)
@CucumberOptions(
   //path of feature file
   features = "src//test//java//com//lti//testing//client//feature/",
   //path of step definition file
   glue = ("com.lti.testing.client.step"),
   plugin = {"pretty", "html:target//cucumber"}
   )
public class TestRunner {
}

